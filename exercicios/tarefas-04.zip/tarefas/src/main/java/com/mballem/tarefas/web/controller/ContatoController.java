package com.mballem.tarefas.web.controller;

import com.mballem.internal.entity.Contato;
import com.mballem.internal.service.ContatoService;

public class ContatoController {

    // EXERCICIO 1
    public Object create() {

        return null;
    }

    // EXERCICIO 2
    public Object getContatoById() {

        return null;
    }

    // EXERCICIO 3
    public Object getContatoByNome() {

        return null;
    }

    // EXERCICIO 4
    public Object getQuantidadeDeContatos() {

        return null;
    }

    // EXERCICIO 5
    public Object getContatosByDataNascimento() {

        return null;
    }

    // EXERCICIO 6
    public Object updateContatoById() {

        return null;
    }

    // EXERCICIO 7
    public Object deleteById() {

        return null;
    }
}
